#pragma once

#include <stdio.h>
#include <SFML/Graphics.h>

#define EXIT_FAILURE	-1
#define EXIT_SUCCESS	 0

int main()
{
	printf("Hello, World!\n");

	return EXIT_SUCCESS;
}
